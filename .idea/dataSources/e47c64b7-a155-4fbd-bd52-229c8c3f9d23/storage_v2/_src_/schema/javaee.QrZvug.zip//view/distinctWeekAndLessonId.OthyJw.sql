create view distinctWeekAndLessonId as
  select distinct
    `javaee`.`ATTENDENCE`.`WEEK`     AS `WEEK`,
    `javaee`.`ATTENDENCE`.`LESSONID` AS `lessonid`
  from `javaee`.`ATTENDENCE`;

