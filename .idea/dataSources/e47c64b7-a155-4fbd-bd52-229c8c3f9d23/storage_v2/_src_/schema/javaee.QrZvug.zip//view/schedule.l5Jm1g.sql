create view schedule as
  select
    `javaee`.`COURSETABLE`.`LESSONID` AS `lessonid`,
    `javaee`.`CLASS1`.`CLASSID`       AS `classid`,
    `javaee`.`DETAIL`.`CLASSROOMID`   AS `classroomid`,
    `javaee`.`DETAIL`.`DDAY`          AS `dday`,
    `javaee`.`DETAIL`.`DTIME`         AS `dtime`,
    `javaee`.`COURSE`.`COURSEID`      AS `courseid`,
    `javaee`.`COURSE`.`NAME`          AS `courseName`,
    `javaee`.`TEACHER`.`TEACHERID`    AS `teacherid`,
    `javaee`.`TEACHER`.`NAME`         AS `teacherName`
  from (((((`javaee`.`DETAIL`
    join `javaee`.`COURSE`) join `javaee`.`COURSETEACHER`) join `javaee`.`TEACHER`) join `javaee`.`COURSETABLE`) join
    `javaee`.`CLASS1`)
  where ((`javaee`.`COURSETABLE`.`CLASSID` = `javaee`.`CLASS1`.`CLASSID`) and
         (`javaee`.`COURSETABLE`.`DETAILID` = `javaee`.`DETAIL`.`DETAILID`) and
         (`javaee`.`COURSETABLE`.`COURSETEACHERID` = `javaee`.`COURSETEACHER`.`COURSETEACHERID`) and
         (`javaee`.`COURSETEACHER`.`COURSEID` = `javaee`.`COURSE`.`COURSEID`) and
         (`javaee`.`COURSETEACHER`.`TEACHERID` = `javaee`.`TEACHER`.`TEACHERID`));

