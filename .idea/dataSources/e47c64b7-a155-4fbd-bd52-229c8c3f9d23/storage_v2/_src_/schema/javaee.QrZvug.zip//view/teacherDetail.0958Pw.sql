create view teacherDetail as
  select
    `javaee`.`TEACHER`.`TEACHERID` AS `teacherId`,
    `javaee`.`TEACHER`.`NAME`      AS `name`,
    `javaee`.`MAJOR`.`NAME`        AS `major`,
    `javaee`.`COLLEGE`.`NAME`      AS `college`,
    `javaee`.`TEACHER`.`PASSWORD`  AS `PASSWORD`
  from `javaee`.`TEACHER`
    join `javaee`.`MAJOR`
    join `javaee`.`COLLEGE`
  where ((`javaee`.`TEACHER`.`MAJORID` = `javaee`.`MAJOR`.`MAJORID`) and
         (`javaee`.`MAJOR`.`COLLEGEID` = `javaee`.`COLLEGE`.`COLLEGEID`));

