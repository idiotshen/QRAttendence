create view studentdetail as
  select
    `javaee`.`STUDENT`.`STUDENTID` AS `STUDENTID`,
    `javaee`.`STUDENT`.`NAME`      AS `studentName`,
    `javaee`.`STUDENT`.`SEX`       AS `SEX`,
    `javaee`.`STUDENT`.`CLASSID`   AS `CLASSID`,
    `javaee`.`MAJOR`.`NAME`        AS `majorName`,
    `javaee`.`COLLEGE`.`NAME`      AS `collegeName`,
    `javaee`.`STUDENT`.`PASSWORD`  AS `password`
  from `javaee`.`STUDENT`
    join `javaee`.`CLASS1`
    join `javaee`.`MAJOR`
    join `javaee`.`COLLEGE`
  where ((`javaee`.`STUDENT`.`CLASSID` = `javaee`.`CLASS1`.`CLASSID`) and
         (`javaee`.`CLASS1`.`MAJORID` = `javaee`.`MAJOR`.`MAJORID`) and
         (`javaee`.`MAJOR`.`COLLEGEID` = `javaee`.`COLLEGE`.`COLLEGEID`));

