create view unattendenceDetail as
  select
    `javaee`.`STUDENT`.`STUDENTID`       AS `STUDENTID`,
    `distinctWeekAndLessonId`.`lessonid` AS `LESSONID`,
    `distinctWeekAndLessonId`.`WEEK`     AS `WEEK`,
    `javaee`.`DETAIL`.`DDAY`             AS `DDAY`,
    `javaee`.`DETAIL`.`DTIME`            AS `DTIME`,
    `javaee`.`DETAIL`.`CLASSROOMID`      AS `CLASSROOMID`,
    `javaee`.`COURSETEACHER`.`TEACHERID` AS `TEACHERID`
  from `javaee`.`STUDENT`
    join `javaee`.`distinctWeekAndLessonId`
    join `javaee`.`DETAIL`
    join `javaee`.`COURSETABLE`
    join `javaee`.`COURSETEACHER`
  where (
    (not ((`javaee`.`STUDENT`.`STUDENTID`, `distinctWeekAndLessonId`.`lessonid`, `distinctWeekAndLessonId`.`WEEK`) in
          (select
             `javaee`.`ATTENDENCE`.`STUDENTID`,
             `javaee`.`ATTENDENCE`.`LESSONID`,
             `javaee`.`ATTENDENCE`.`WEEK`
           from `javaee`.`ATTENDENCE`))) and (`javaee`.`DETAIL`.`DETAILID` = `javaee`.`COURSETABLE`.`DETAILID`) and
    (`javaee`.`COURSETABLE`.`LESSONID` = `distinctWeekAndLessonId`.`lessonid`) and
    (`javaee`.`COURSETEACHER`.`COURSETEACHERID` = `javaee`.`COURSETABLE`.`COURSETEACHERID`))
  order by `javaee`.`STUDENT`.`STUDENTID`;

